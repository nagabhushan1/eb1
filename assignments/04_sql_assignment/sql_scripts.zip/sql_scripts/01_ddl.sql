CREATE TABLE departments (
    department_id   NUMBER(5) PRIMARY KEY,
    department_name VARCHAR2(50) NOT NULL
);

CREATE TABLE categories (
    category_id     NUMBER(5) PRIMARY KEY,
    category_department_id NUMBER(5) NOT NULL,
    category_name   VARCHAR2(50) NOT NULL,
    CONSTRAINT fk_category_dept FOREIGN KEY (category_department_id)
        REFERENCES departments(department_id)
);

CREATE TABLE products (
    product_id      NUMBER(10) PRIMARY KEY,
    product_category_id NUMBER(5) NOT NULL,
    product_name    VARCHAR2(100) NOT NULL,
    product_description VARCHAR2(255),
    product_price   NUMBER(10,2) NOT NULL,
    product_image   VARCHAR2(255),
    CONSTRAINT fk_product_category FOREIGN KEY (product_category_id)
        REFERENCES categories(category_id)
);

CREATE TABLE customers (
    customer_id         NUMBER(10) PRIMARY KEY,
    customer_fname      VARCHAR2(50) NOT NULL,
    customer_lname      VARCHAR2(50) NOT NULL,
    customer_email      VARCHAR2(100) UNIQUE,
    customer_password   VARCHAR2(50),
    customer_street     VARCHAR2(200),
    customer_city       VARCHAR2(50),
    customer_state      VARCHAR2(50),
    customer_zipcode    VARCHAR2(20)
);

CREATE TABLE orders (
    order_id       NUMBER(10) PRIMARY KEY,
    order_date     DATE DEFAULT SYSDATE,
    order_customer_id NUMBER(10) NOT NULL,
    order_status   VARCHAR2(30),
    CONSTRAINT fk_order_customer FOREIGN KEY (order_customer_id)
        REFERENCES customers(customer_id)
);

CREATE TABLE order_items (
    order_item_id        NUMBER(10) PRIMARY KEY,
    order_item_order_id  NUMBER(10) NOT NULL,
    order_item_product_id NUMBER(10) NOT NULL,
    order_item_quantity  NUMBER(5) NOT NULL,
    order_item_subtotal  NUMBER(10,2) NOT NULL,
    order_item_product_price NUMBER(10,2) NOT NULL,
    CONSTRAINT fk_item_order FOREIGN KEY (order_item_order_id)
        REFERENCES orders(order_id),
    CONSTRAINT fk_item_product FOREIGN KEY (order_item_product_id)
        REFERENCES products(product_id)
);


SET DEFINE OFF
SET ECHO OFF
INSERT ALL
  INTO departments (department_id, department_name) VALUES (2, 'Fitness')
  INTO departments (department_id, department_name) VALUES (3, 'Footwear')
  INTO departments (department_id, department_name) VALUES (4, 'Apparel')
  INTO departments (department_id, department_name) VALUES (5, 'Golf')
  INTO departments (department_id, department_name) VALUES (6, 'Outdoors')
  INTO departments (department_id, department_name) VALUES (7, 'Fan Shop')
  INTO departments (department_id, department_name) VALUES (8, 'Fan Gear')
SELECT 1 FROM DUAL;
COMMIT;

